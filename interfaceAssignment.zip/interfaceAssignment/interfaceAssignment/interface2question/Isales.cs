﻿using System;
using System.Collections.Generic;
using System.Text;

namespace interface2question
{
    internal interface Isales
    {
        int yearlySales(int monthlySales);
    }
}
