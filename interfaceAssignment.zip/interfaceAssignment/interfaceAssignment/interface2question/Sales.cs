﻿using System;
using System.Collections.Generic;
using System.Text;

namespace interface2question
{
    internal abstract class Sales
    {
        public abstract int monthlySales(int dailySales);

        public int dailySales()
        {
            return 400;
        }

    }
}
