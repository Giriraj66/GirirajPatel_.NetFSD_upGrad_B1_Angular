﻿namespace interface2question
{
    internal class Program : Sales,Isales
    {
        public override int monthlySales(int dailySales)
        {
            return dailySales * 30;
        }

        public int yearlySales(int monthlySales)
        {
            return monthlySales * 12;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            Program obj = new Program();

            int daily = obj.dailySales();
            int monthly = obj.monthlySales(daily);
            int yearly = obj.yearlySales(monthly);

            Console.WriteLine("Daily sales: Rs." + daily);
            Console.WriteLine("Monthly sales: Rs." + monthly);
            Console.WriteLine("Annual sales: Rs." + yearly);
        }
    }
}
