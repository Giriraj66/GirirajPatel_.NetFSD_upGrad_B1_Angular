﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace exceptionhandling1question
{
    internal class BankAccount
    {
        public int accountnumber { get; set; }
        public string name { get; set; }
        public  double balance;
        public char transactiontype;
        public double transactionamount;

        public BankAccount(int accountnumber,string name,double balance)
        {
            accountnumber = accountnumber;
            name = name;
            balance = balance;
        }
        public void performTransaction()
        {
            if (transactiontype == 'd' || transactiontype == 'D')
            {
                balance += transactionamount;
                Console.WriteLine("Amount Deposited succesfully");
            }
            else if (transactiontype == 'c' || transactiontype == 'C')
            {
                if (balance - transactionamount >= 500)
                {
                    throw new CheckBalanceException("balance cannot go below 500");
                }
                else
                {
                    balance -= transactionamount;
                    Console.WriteLine("amout withdraw");
                }
            }
            else
            {
                Console.WriteLine("Invalid Transaction Type");
            }
        }

            public void Display()
            {
                Console.WriteLine("Account Number: " + accountnumber);
                Console.WriteLine("Name: " + name);
                Console.WriteLine("Balance: " + balance);
            }

    }
}
