﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exceptionhandling1question
{
    internal class CheckBalanceException : Exception
    {
        public CheckBalanceException(string message) : base(message)
        {

        }
    }
}
