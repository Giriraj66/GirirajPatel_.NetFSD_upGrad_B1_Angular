﻿namespace exceptionhandling1question
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            try
            {
              
                BankAccount acc = new BankAccount(101, "Giriraj", 1000);

                // Input Transaction
                Console.WriteLine("Enter Transaction Type (d/c): ");
                string input = Console.ReadLine();

                acc.transactiontype = char.ToLower(input[0]);

                Console.WriteLine("Enter Amount: ");
                acc.transactionamount = Convert.ToDouble(Console.ReadLine());

                acc.performTransaction();
                acc.Display();
            }
            catch (CheckBalanceException ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }
}
