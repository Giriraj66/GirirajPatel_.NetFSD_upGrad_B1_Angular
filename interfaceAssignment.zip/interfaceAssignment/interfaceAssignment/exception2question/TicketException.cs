﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exception2question
{
    internal class TicketException : Exception
    {
        public TicketException(String message) : base(message)
        {

        }
    }
}
