﻿using System;
using System.Collections.Generic;
using System.Text;

namespace exception2question
{
    internal class TicketBooking
    {
        private int availableTickets = 15;

        public void BookTickets(int tickets)
        {
            if (tickets > availableTickets)
            {
                throw new TicketException("Tickets not available. Only " + availableTickets + " left.");
            }

            availableTickets -= tickets;

            Console.WriteLine("Tickets Booked Successfully!");
            Console.WriteLine("Remaining Tickets: " + availableTickets);
        }
    }
}
