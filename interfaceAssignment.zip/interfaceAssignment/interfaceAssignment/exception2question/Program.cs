﻿namespace exception2question
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            TicketBooking tb = new TicketBooking();

            try
            {
                Console.WriteLine("Do you want to book tickets? (yes/no)");
                string choice = Console.ReadLine().ToLower();

                if (choice == "yes")
                {
                    Console.WriteLine("Enter number of tickets:");
                    int tickets = Convert.ToInt32(Console.ReadLine());

                    tb.BookTickets(tickets);
                }
                else
                {
                    Console.WriteLine("Thank you!");
                }
            }
            catch (TicketException ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }
}
