﻿using System;
using System.Collections.Generic;
using System.Text;

namespace interface1Question
{
    public class TCS  : GovtRules
    {
        private int empid;
        private string name;
        private string dept,desg;
        private double basicsalary;

        public TCS(int empid,string name,string dept,string desg,double basicsalary)
        {
            this.empid = empid;
            this.name = name;
            this.dept = dept;
            this.desg = desg;
            this.basicsalary = basicsalary;
        }
        public int EmpId => empid;
        public string Name => name;
        public string Dept => dept;
        public string Desg => desg;
        public double BasicSalary => basicsalary;

        public double EmployeePF(double basicsalary)
        {
            double empPF = basicsalary * 0.12;
            double employerPF = basicsalary * 0.0833;
            double pension = basicsalary * 0.0367;

            Console.WriteLine("Employer PF: " + employerPF);
            Console.WriteLine("Pension Fund: " + pension);

            return empPF;
        }

        public string LeaveDetails()
        {
            return "1 Casual Leave/month\n12 Sick Leave/year\n10 Privilege Leave/year";
        }

        public double GratuityAmount(float service, double salary)
        {
            if (service > 20) return 3 * salary;
            else if (service > 10) return 2 * salary;
            else if (service > 5) return salary;
            else return 0;
        }

    }
}
