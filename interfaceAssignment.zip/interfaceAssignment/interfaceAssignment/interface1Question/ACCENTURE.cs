﻿using System;
using System.Collections.Generic;
using System.Text;

namespace interface1Question
{
    internal class ACCENTURE : GovtRules
    {
        private int empid;
        private string name, dept, desg;
        private double basicsalary;

        public ACCENTURE(int empid, string name,string dept, string desg,double basicsalary)
        {
            this.empid = empid;
            this.name = name;
            this.dept = dept;
            this.desg = desg;
            this.basicsalary = basicsalary;
        }

        public int EmpId => empid;
        public string Name => name;
        public string Dept => dept;
        public string Desg => desg;
        public double BasicSalary => basicsalary;

        public double EmployeePF(double basicSalary)
        {
            double empPF = basicSalary * 0.12;
            double employerPF = basicSalary * 0.12;

            Console.WriteLine("Employer PF: " + employerPF);

            return empPF;
        }
        public string LeaveDetails()
        {
            return "2 Casual Leave/month\n5 Sick Leave/year\n5 Privilege Leave/year";
        }

        public double GratuityAmount(float service, double salary)
        {
            return 0;
        }

    }
}
