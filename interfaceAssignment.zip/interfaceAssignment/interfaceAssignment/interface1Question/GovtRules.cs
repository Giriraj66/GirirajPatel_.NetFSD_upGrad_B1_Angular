﻿using System;
using System.Collections.Generic;
using System.Text;

namespace interface1Question
{
    public interface GovtRules
    {
        double EmployeePF(double basicSalary);
        string LeaveDetails();
        double GratuityAmount(float serviceCompleted, double basicSalary);
    }
}

