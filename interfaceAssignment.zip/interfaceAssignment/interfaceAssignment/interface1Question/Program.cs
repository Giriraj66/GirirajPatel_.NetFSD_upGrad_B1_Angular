﻿namespace interface1Question
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello, World!");

            //TCS tcs = new TCS(1, "Giriraj", "IT", "Developer", 50000);

            
            //Console.WriteLine(tcs.EmpId);
            //Console.WriteLine(tcs.Name);
            //Console.WriteLine(tcs.Dept);
            //Console.WriteLine(tcs.Desg);
            //Console.WriteLine(tcs.BasicSalary);

            //Console.WriteLine("Employee PF: " + tcs.EmployeePF(tcs.BasicSalary));
            //Console.WriteLine(tcs.LeaveDetails());
            //Console.WriteLine("Gratuity: " + tcs.GratuityAmount(6, tcs.BasicSalary));


            ACCENTURE acc = new ACCENTURE(2, "Rahul", "HR", "Manager", 60000);

            Console.WriteLine("---- Accenture ----");
            Console.WriteLine(acc.EmpId);
            Console.WriteLine(acc.Name);
            Console.WriteLine(acc.Dept);
            Console.WriteLine(acc.Desg);
            Console.WriteLine(acc.BasicSalary);

            Console.WriteLine("Employee PF: " + acc.EmployeePF(acc.BasicSalary));
            Console.WriteLine(acc.LeaveDetails());
            Console.WriteLine("Gratuity: " + acc.GratuityAmount(6, acc.BasicSalary));
        }
    }
}
