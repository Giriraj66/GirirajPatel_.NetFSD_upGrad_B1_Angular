﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Collection5Assignment
{
    internal class Patient
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Disease { get; set; }
    }
}
