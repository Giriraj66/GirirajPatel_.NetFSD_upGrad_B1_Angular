﻿namespace Collection5Assignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello, World!");
            Queue<Patient> queue = new Queue<Patient>();
            queue.Enqueue(new Patient { Id = 1, Name = "A", Disease = "Fever" });
            queue.Enqueue(new Patient { Id = 2, Name = "B", Disease = "Cold" });
            queue.Enqueue(new Patient { Id = 3, Name = "C", Disease = "Flu" });
            queue.Enqueue(new Patient { Id = 4, Name = "D", Disease = "Cough" });
            queue.Enqueue(new Patient { Id = 5, Name = "E", Disease = "Headache" });

            //for (int i = 0; i < 2; i++)
            //{
            //    if (queue.Count > 0)
            //    {
            //        var served = queue.Dequeue();
            //        Console.WriteLine("Served: " + served.Name);
            //    }
            //}


            //if (queue.Count > 0)
            //{
            //    Console.WriteLine("Next Patient: " + queue.Peek().Name);
            //}
            foreach (var p in queue)
            {
                Console.WriteLine($"{p.Id} {p.Name} {p.Disease}");
            }
            Queue<Patient> vipQueue = new Queue<Patient>();
            vipQueue.Enqueue(new Patient { Id = 6, Name = "VIP1", Disease = "Emergency" });

            while (vipQueue.Count > 0)
            {
                Console.WriteLine("VIP Served: " + vipQueue.Dequeue().Name);
            }
        }
    }
}
