﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Collection2question
{
    internal class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Marks { get; set; }
    }
}
