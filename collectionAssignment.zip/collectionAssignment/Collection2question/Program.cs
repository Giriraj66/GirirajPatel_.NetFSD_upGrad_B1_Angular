﻿namespace Collection2question
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            Dictionary<int, Student> students = new Dictionary<int, Student>();

      
            students.Add(1, new Student { Id = 1, Name = "raj", Marks = 80 });
            students.Add(2, new Student { Id = 2, Name = "max", Marks = 65 });
            students.Add(3, new Student { Id = 3, Name = "giri", Marks = 90 });
            students.Add(4, new Student { Id = 4, Name = "gaju", Marks = 70 });
            students.Add(5, new Student { Id = 5, Name = "ggggg", Marks = 85 });

            int id = 3;
            if (students.ContainsKey(id))
            {
                Console.WriteLine($"{students[id].Id} {students[id].Name} {students[id].Marks}");
            }
            int checkId = 2;
            Console.WriteLine(students.ContainsKey(checkId));

            int updateId = 1;
            if (students.ContainsKey(updateId))
            {
                students[updateId].Marks = 95;
            }

            int removeId = 4;
            if (students.ContainsKey(removeId))
            {
                students.Remove(removeId);
            }

            var result = students.Values.Where(s => s.Marks > 75);
            foreach (var s in result)
            {
                Console.WriteLine($"{s.Id} {s.Name} {s.Marks}");
            }
        }
    }
}
