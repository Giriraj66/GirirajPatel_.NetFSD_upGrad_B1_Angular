﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello, World!");
            List<Product> products = new List<Product>()
        {
            new Product { Id = 1, Name = "Laptop", Price = 50000, Category = "Electronics" },
            new Product { Id = 2, Name = "Mobile", Price = 20000, Category = "Electronics" },
            new Product { Id = 3, Name = "Shoes", Price = 1500, Category = "Fashion" },
            new Product { Id = 4, Name = "Watch", Price = 3000, Category = "Accessories" },
            new Product { Id = 5, Name = "Bag", Price = 1200, Category = "Fashion" },
            new Product { Id = 6, Name = "Keyboard", Price = 800, Category = "Electronics" },
            new Product { Id = 7, Name = "Mouse", Price = 500, Category = "Electronics" },
            new Product { Id = 8, Name = "Chair", Price = 2500, Category = "Furniture" },
            new Product { Id = 9, Name = "Table", Price = 4000, Category = "Furniture" },
            new Product { Id = 10, Name = "Headphones", Price = 1800, Category = "Electronics" }
        };
            //foreach (var p in products)
            //{
            //    Console.WriteLine($"{p.Id} {p.Name} {p.Price} {p.Category}");
            //}

            //var result = products.Where(p => p.Price > 1000);
            //foreach (var p in result)
            //{
            //    Console.WriteLine($"{p.Id} {p.Name} {p.Price} {p.Category}");
            //}

            //var asc = products.OrderBy(p => p.Price);
            //foreach (var p in asc)
            //{
            //    Console.WriteLine($"{p.Id} {p.Name} {p.Price} {p.Category}");
            //}

            //var desc = products.OrderByDescending(p => p.Price);
            //foreach (var p in desc)
            //{
            //    Console.WriteLine($"{p.Id} {p.Name} {p.Price} {p.Category}");
            //}

            //int id = 5;
            //var remove = products.FirstOrDefault(p => p.Id == id);
            //if (remove != null)
            //{
            //    products.Remove(remove);
            //}

            var category = products.Where(p => p.Category == "Electronics");
            foreach (var p in category)
            {
                Console.WriteLine($"{p.Id} {p.Name} {p.Price} {p.Category}");
            }
        }
    }
}
