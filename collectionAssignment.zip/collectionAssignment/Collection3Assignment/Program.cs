﻿namespace Collection3Assignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            HashSet<string> emails = new HashSet<string>()
        {
            "raj@gmail.com",
            "max@gmail.com",
            "giri@gmail.com",
            "sonu@gmail.com",
            "raj@gmail.com",
            "ankit@gmail.com",
            "jaydeep@gmail.com",
            "max@gmail.com",
            "anubhav@gmail.com",
            "bhargav@gmail.com"
        };


            //foreach (var email in emails)
            //{
            //    Console.WriteLine(email);
            //}


            //string checkEmail = "raj@gmail.com";
            //Console.WriteLine(emails.Contains(checkEmail));

            //string removeEmail = "raj@gmail.com";
            //emails.Remove(removeEmail);

            HashSet<string> event1 = new HashSet<string>() { "a@gmail.com", "b@gmail.com", "x@gmail.com" };
            HashSet<string> event2 = new HashSet<string>() { "b@gmail.com", "c@gmail.com", "x@gmail.com" };

            var common = event1.Intersect(event2);
            foreach (var email in common)
            {
                Console.WriteLine(email);
            }
        }
    }
}
