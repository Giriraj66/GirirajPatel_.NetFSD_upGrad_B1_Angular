﻿namespace Collection4Assignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //  Console.WriteLine("Hello, World!");
            Stack<string> actions = new Stack<string>();
            actions.Push("Type A");
            actions.Push("Type B");
            actions.Push("Delete B");
            actions.Push("Type C");
            actions.Push("Delete A");

            Stack<string> redoStack = new Stack<string>();


            //for (int i = 0; i < 3; i++)
            //{
            //    if (actions.Count > 0)
            //    {
            //        string undone = actions.Pop();
            //        redoStack.Push(undone);
            //        Console.WriteLine("Undo: " + undone);
            //    }
            //}

            //if (actions.Count > 0)
            //{
            //    Console.WriteLine("Current Top: " + actions.Peek());
            //}

            if (redoStack.Count > 0)
            {
                string redo = redoStack.Pop();
                actions.Push(redo);
                Console.WriteLine("Redo: " + redo);
            }
        }
    }
}
