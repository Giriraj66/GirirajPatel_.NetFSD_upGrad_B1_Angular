﻿namespace Collection6Assignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello, World!");
            LinkedList<Song> playlist = new LinkedList<Song>();

            var s1 = new Song { Id = 1, Title = "Song1", Artist = "A" };
            var s2 = new Song { Id = 2, Title = "Song2", Artist = "B" };
            var s3 = new Song { Id = 3, Title = "Song3", Artist = "C" };
            var s4 = new Song { Id = 4, Title = "Song4", Artist = "D" };

            playlist.AddFirst(s1);                 
            playlist.AddLast(s2);                  
            var node = playlist.AddLast(s3);      
            playlist.AddAfter(node, s4);       

            var temp = playlist.First;
            while (temp != null)
            {
                if (temp.Value.Id == 2)
                {
                    playlist.Remove(temp);
                    break;
                }
                temp = temp.Next;
            }

            var current = playlist.First;
            while (current != null)
            {
                Console.WriteLine(current.Value.Title);
                current = current.Next;
            }

            current = playlist.Last;
            while (current != null)
            {
                Console.WriteLine(current.Value.Title);
                current = current.Previous;
            }

            current = playlist.First;
            while (current != null)
            {
                if (current.Value.Title == "Song3")
                    Console.WriteLine("Found: " + current.Value.Title);
                current = current.Next;
            }

            var currentSong = playlist.First;
            if (currentSong != null && currentSong.Next != null)
                Console.WriteLine("Play Next: " + currentSong.Next.Value.Title);
        }
    }
}
