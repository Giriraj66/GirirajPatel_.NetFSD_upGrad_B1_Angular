﻿namespace Assignment2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello, World!");
            List<int> numbers = new List<int> { 5, 10, 15, 20, 25, 30 };

            var evenNumbers = numbers.Where(n => n % 2 == 0);
            Console.WriteLine("Even numbers:");
            foreach (var num in evenNumbers)
            {
                Console.WriteLine(num);
            }

            var greaterThan15 = numbers.Where(n => n > 15);
            Console.WriteLine("Numbers greater than 15:");
            foreach (var num in greaterThan15)
            {
                Console.WriteLine(num);
            }

            var squares = numbers.Select(n => n * n);
            Console.WriteLine("Squares of numbers:");
            foreach (var square in squares)
            {
                Console.WriteLine(square);
            }

            int divisibleBy5Count = numbers.Count(n => n % 5 == 0);
            Console.WriteLine("Count of numbers divisible by 5: " + divisibleBy5Count);
        }
    }
}
