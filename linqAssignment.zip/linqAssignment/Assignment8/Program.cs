﻿namespace Assignment8
{
    class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Class { get; set; }
        public string Subject { get; set; }
        public int Marks { get; set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            List<Student> students = new List<Student>
            {
                new Student { Id = 1, Name = "Alice", Class = "10A", Subject = "Math", Marks = 85 },
                new Student { Id = 2, Name = "Bob", Class = "10A", Subject = "Science", Marks = 78 },
                new Student { Id = 3, Name = "Charlie", Class = "10A", Subject = "Math", Marks = 92 },
                new Student { Id = 4, Name = "David", Class = "10B", Subject = "Math", Marks = 88 },
                new Student { Id = 5, Name = "Eve", Class = "10B", Subject = "Science", Marks = 95 },
                new Student { Id = 6, Name = "Frank", Class = "10B", Subject = "Math", Marks = 75 }
            };

            var multiLevelGroup = students.GroupBy(s => s.Class)
                                          .Select(g => new
                                          {
                                              Class = g.Key,
                                              Subjects = g.GroupBy(s => s.Subject)
                                                          .Select(sg => new
                                                          {
                                                              Subject = sg.Key,
                                                              Students = sg
                                                          })
                                          });

            Console.WriteLine("Average marks per subject per class:");
            foreach (var classGroup in multiLevelGroup)
            {
                Console.WriteLine("Class: " + classGroup.Class);
                foreach (var subjectGroup in classGroup.Subjects)
                {
                    double avgMarks = subjectGroup.Students.Average(s => s.Marks);
                    Console.WriteLine("  Subject: " + subjectGroup.Subject + " - Average Marks: " + avgMarks);
                }
            }

        }
    }
}
