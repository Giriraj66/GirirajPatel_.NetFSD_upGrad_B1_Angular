﻿namespace Assignment6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            List<int> numbers = new List<int> { 1, 2, 3, 2, 4, 5, 3, 6 };

            var distinctNumbers = numbers.Distinct();
            Console.WriteLine("Numbers after removing duplicates:");
            foreach (var num in distinctNumbers)
            {
                Console.WriteLine(num);
            }

            Console.WriteLine();

            var duplicateNumbers = numbers.GroupBy(n => n)
                                          .Where(g => g.Count() > 1)
                                          .Select(g => g.Key);
            Console.WriteLine("Duplicate numbers:");
            foreach (var num in duplicateNumbers)
            {
                Console.WriteLine(num);
            }

            Console.WriteLine();

            var countPerNumber = numbers.GroupBy(n => n)
                                        .Select(g => new { Number = g.Key, Count = g.Count() });
            Console.WriteLine("Count of each number:");
            foreach (var item in countPerNumber)
            {
                Console.WriteLine(item.Number + " - " + item.Count);
            }

        }
    }
}
