﻿namespace Assignment3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            List<string> names = new List<string> { "Ravi", "Kiran", "Amit", "Raj", "Anil" };

            var namesStartingWithA = names.Where(n => n.StartsWith("A"));
            Console.WriteLine("Names starting with 'A':");
            foreach (var name in namesStartingWithA)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine();

            var sortedNames = names.OrderBy(n => n);
            Console.WriteLine("Names sorted alphabetically:");
            foreach (var name in sortedNames)
            {
                Console.WriteLine(name);
            }


            var upperCaseNames = names.Select(n => n.ToUpper());
            Console.WriteLine("Names in uppercase:");
            foreach (var name in upperCaseNames)
            {
                Console.WriteLine(name);
            }

            var longNames = names.Where(n => n.Length > 4);
            Console.WriteLine("Names with length > 4:");
            foreach (var name in longNames)
            {
                Console.WriteLine(name);
            }

        }
    }
}
