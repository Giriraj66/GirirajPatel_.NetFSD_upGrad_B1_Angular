﻿namespace Assignment10
{
    class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
        public double Salary { get; set; }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            List<Employee> employees = new List<Employee>
            {
                new Employee { Id = 1, Name = "Alice", Department = "IT", Salary = 60000 },
                new Employee { Id = 2, Name = "Bob", Department = "HR", Salary = 50000 },
                new Employee { Id = 3, Name = "Charlie", Department = "IT", Salary = 70000 },
                new Employee { Id = 4, Name = "David", Department = "Finance", Salary = 55000 },
                new Employee { Id = 5, Name = "Eve", Department = "HR", Salary = 65000 }
            };

            var sortedEmployees = employees.OrderBy(e => e.Department)
                                           .ThenByDescending(e => e.Salary);

            Console.WriteLine("Employees sorted by Department (asc) then Salary (desc):");
            foreach (var emp in sortedEmployees)
            {
                Console.WriteLine(emp.Department + " - " + emp.Name + " - " + emp.Salary);
            }

        }
    }
}
