﻿namespace Assignment9
{
    class Order
    {
        public int Id { get; set; }
        public string CustomerName { get; set; }
        public DateTime OrderDate { get; set; }
        public double TotalAmount { get; set; }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello, World!");

            List<Order> orders = new List<Order>
            {
                new Order { Id = 1, CustomerName = "Alice", OrderDate = DateTime.Now.AddDays(-5), TotalAmount = 2000 },
                new Order { Id = 2, CustomerName = "Bob", OrderDate = DateTime.Now.AddDays(-40), TotalAmount = 3500 },
                new Order { Id = 3, CustomerName = "Charlie", OrderDate = DateTime.Now.AddDays(-15), TotalAmount = 5000 },
                new Order { Id = 4, CustomerName = "Alice", OrderDate = DateTime.Now.AddDays(-20), TotalAmount = 1500 },
                new Order { Id = 5, CustomerName = "David", OrderDate = DateTime.Now.AddDays(-10), TotalAmount = 4000 },
                new Order { Id = 6, CustomerName = "Bob", OrderDate = DateTime.Now.AddDays(-25), TotalAmount = 2500 }
            };

            DateTime last30Days = DateTime.Now.AddDays(-30);

            var recentOrders = orders.Where(o => o.OrderDate >= last30Days);
            Console.WriteLine("Orders placed in last 30 days:");
            foreach (var o in recentOrders)
            {
                Console.WriteLine(o.CustomerName + " - " + o.OrderDate.ToShortDateString() + " - " + o.TotalAmount);
            }

            var monthlySales = orders.GroupBy(o => new { o.OrderDate.Year, o.OrderDate.Month })
                                     .Select(g => new
                                     {
                                         Year = g.Key.Year,
                                         Month = g.Key.Month,
                                         TotalSales = g.Sum(o => o.TotalAmount)
                                     });
            Console.WriteLine("Monthly sales report:");
            foreach (var m in monthlySales)
            {
                Console.WriteLine("Year: " + m.Year + " Month: " + m.Month + " - Total Sales: " + m.TotalSales);
            }

            var topCustomers = orders.GroupBy(o => o.CustomerName)
                                     .Select(g => new { Customer = g.Key, TotalSpent = g.Sum(o => o.TotalAmount) })
                                     .OrderByDescending(c => c.TotalSpent)
                                     .Take(5);
            Console.WriteLine("Top 5 customers by spending:");
            foreach (var c in topCustomers)
            {
                Console.WriteLine(c.Customer + " - " + c.TotalSpent);
            }

            var highestOrderPerMonth = orders.GroupBy(o => new { o.OrderDate.Year, o.OrderDate.Month })
                                             .Select(g => new
                                             {
                                                 Year = g.Key.Year,
                                                 Month = g.Key.Month,
                                                 HighestOrder = g.OrderByDescending(o => o.TotalAmount).First()
                                             });
            Console.WriteLine("Highest order per month:");
            foreach (var item in highestOrderPerMonth)
            {
                Console.WriteLine("Year: " + item.Year + " Month: " + item.Month + " - " +
                                  item.HighestOrder.CustomerName + " - " + item.HighestOrder.TotalAmount);
            }

        }
    }
}
