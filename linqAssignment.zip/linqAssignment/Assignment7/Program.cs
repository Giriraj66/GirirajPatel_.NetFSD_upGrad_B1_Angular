﻿namespace Assignment7
{
    class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public double Price { get; set; }
        public int Stock { get; set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            List<Product> products = new List<Product>
            {
                new Product { Id = 1, Name = "Laptop", Category = "Electronics", Price = 80000, Stock = 5 },
                new Product { Id = 2, Name = "Mouse", Category = "Electronics", Price = 800, Stock = 50 },
                new Product { Id = 3, Name = "Keyboard", Category = "Electronics", Price = 1500, Stock = 8 },
                new Product { Id = 4, Name = "Chair", Category = "Furniture", Price = 3000, Stock = 15 },
                new Product { Id = 5, Name = "Table", Category = "Furniture", Price = 5000, Stock = 3 },
                new Product { Id = 6, Name = "Notebook", Category = "Stationery", Price = 50, Stock = 100 }
            };

            var lowStockProducts = products.Where(p => p.Stock < 10);
            Console.WriteLine("Products with stock less than 10:");
            foreach (var p in lowStockProducts)
            {
                Console.WriteLine(p.Name + " - " + p.Stock);
            }

            var top3Expensive = products.OrderByDescending(p => p.Price).Take(3);
            Console.WriteLine("Top 3 expensive products:");
            foreach (var p in top3Expensive)
            {
                Console.WriteLine(p.Name + " - " + p.Price);
            }

            var groupedByCategory = products.GroupBy(p => p.Category);
            Console.WriteLine("Products grouped by category:");
            foreach (var group in groupedByCategory)
            {
                Console.WriteLine("Category: " + group.Key);
                foreach (var p in group)
                {
                    Console.WriteLine("  " + p.Name + " - " + p.Price + " - " + p.Stock);
                }
            }


            var totalStockPerCategory = products.GroupBy(p => p.Category)
                                                .Select(g => new { Category = g.Key, TotalStock = g.Sum(p => p.Stock) });
            Console.WriteLine("Total stock per category:");
            foreach (var item in totalStockPerCategory)
            {
                Console.WriteLine(item.Category + " - " + item.TotalStock);
            }

            bool anyOutOfStock = products.Any(p => p.Stock == 0);
            Console.WriteLine("Any product out of stock? " + anyOutOfStock);
        }
    }
}
