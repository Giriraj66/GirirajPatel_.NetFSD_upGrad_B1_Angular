﻿namespace Assignment4
{
    internal class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
        public double Salary { get; set; }

        static void Main(string[] args)
        {
           // Console.WriteLine("Hello, World!");

            List<Employee> employees = new List<Employee>
            {
                new Employee { Id = 1, Name = "Alice", Department = "IT", Salary = 60000 },
                new Employee { Id = 2, Name = "Bob", Department = "HR", Salary = 50000 },
                new Employee { Id = 3, Name = "Charlie", Department = "IT", Salary = 70000 },
                new Employee { Id = 4, Name = "David", Department = "Finance", Salary = 55000 },
                new Employee { Id = 5, Name = "Eve", Department = "HR", Salary = 65000 }
            };

            var itEmployees = employees.Where(e => e.Department == "IT");
            Console.WriteLine("Employees from IT department:");
            foreach (var emp in itEmployees)
            {
                Console.WriteLine(emp.Name + " - " + emp.Department + " - " + emp.Salary);
            }

            var highestSalary = employees.OrderByDescending(e => e.Salary).First();
            Console.WriteLine("Employee with highest salary:");
            Console.WriteLine(highestSalary.Name + "  " + highestSalary.Department + " " + highestSalary.Salary);

            var averageSalary = employees.Average(e => e.Salary);
            Console.WriteLine("Average salary of employees: " + averageSalary);


            var groupedByDept = employees.GroupBy(e => e.Department);
            Console.WriteLine("Employees grouped by department:");
            foreach (var group in groupedByDept)
            {
                Console.WriteLine("Department: " + group.Key);
                foreach (var emp in group)
                {
                    Console.WriteLine("  " + emp.Name + " - " + emp.Salary);
                }
            }

            var countByDept = employees.GroupBy(e => e.Department)
                                       .Select(g => new { Department = g.Key, Count = g.Count() });
            Console.WriteLine("Count of employees in each department:");
            foreach (var item in countByDept)
            {
                Console.WriteLine(item.Department + " - " + item.Count);
            }

        }
    }
}
