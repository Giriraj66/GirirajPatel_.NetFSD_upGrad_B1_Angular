﻿namespace Assignment1
{
    internal class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public int Marks { get; set; }
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            List<Student> students = new List<Student>()
            {
                new Student { Id = 1, Name = "Raja", Age = 20, Marks = 85 },
                new Student { Id = 2, Name = "Max", Age = 17, Marks = 70 },
                new Student { Id = 3, Name = "Charlie", Age = 23, Marks = 90 },
                new Student { Id = 4, Name = "David", Age = 19, Marks = 60 },
                new Student { Id = 5, Name = "Eve", Age = 22, Marks = 78 }
            };
            var highMarksStudents = students.Where(s => s.Marks > 75).ToList();
            foreach (var student in highMarksStudents)
            {
                Console.WriteLine(student.Name + " - " + student.Marks);
            }

            var ageFilteredStudents = students.Where(s => s.Age >= 18 && s.Age <= 25).ToList();
            foreach (var student in ageFilteredStudents)
            {
                Console.WriteLine(student.Name + " - " + student.Age);
            }


            var sortedStudents = students.OrderByDescending(s => s.Marks).ToList();
            foreach (var student in sortedStudents)
            {
                Console.WriteLine(student.Name + " - " + student.Marks);
            }

            var nameAndMarks = students.Select(s => new { s.Name, s.Marks }).ToList();
            Console.WriteLine("Name and Marks of all students:");
            foreach (var item in nameAndMarks)
            {
                Console.WriteLine(item.Name + " - " + item.Marks);
            }
    }
    }
}
