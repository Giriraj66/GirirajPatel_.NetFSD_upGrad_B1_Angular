﻿namespace Assignment1
{
    internal class Program
    {
        static string filePath = "employee_log.txt";
        static void Main(string[] args)
        {
            while (true)
            {
                //Console.WriteLine("Hello, World!");
                Console.WriteLine("1. Add Login Entry");
                Console.WriteLine("2. Update Logout Time");
                Console.WriteLine("3. View Logs");
                Console.WriteLine("4. Exit");
                Console.Write("Enter choice: ");

                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddLogin();
                        break;
                    case 2:
                        UpdateLogout();
                        break;
                    case 3:
                        ViewLogs();
                        break;
                    case 4:
                        return;
                    default:
                        Console.WriteLine("Invalid choice!");
                        break;
                }
            }
        }
        static void AddLogin()
        {
            try
            {
                Console.Write("Enter Employee ID: ");
                string id = Console.ReadLine();

                Console.Write("Enter Name: ");
                string name = Console.ReadLine();

                string loginTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                using (StreamWriter sw = new StreamWriter(filePath, true)) 
                {
                    sw.WriteLine($"{id}|{name}|{loginTime}|-");
                }

                Console.WriteLine("Login recorded successfully!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                Console.WriteLine("AddLogin operation completed.");
            }
        }

      
        static void UpdateLogout()
        {
            try
            {
                Console.Write("Enter Employee ID to logout: ");
                string id = Console.ReadLine();

                if (!File.Exists(filePath))
                {
                    Console.WriteLine("Log file not found!");
                    return;
                }

                List<string> lines = new List<string>(File.ReadAllLines(filePath));
                bool found = false;

                for (int i = 0; i < lines.Count; i++)
                {
                    string[] parts = lines[i].Split('|');

                    if (parts[0] == id && parts[3] == "-")
                    {
                        parts[3] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        lines[i] = string.Join("|", parts);
                        found = true;
                        break;
                    }
                }

                if (found)
                {
                    File.WriteAllLines(filePath, lines);
                    Console.WriteLine("Logout time updated!");
                }
                else
                {
                    Console.WriteLine("Employee not found or already logged out.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                Console.WriteLine("UpdateLogout operation completed.");
            }
        }

        static void ViewLogs()
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    Console.WriteLine("No logs found!");
                    return;
                }

                using (StreamReader sr = new StreamReader(filePath))
                {
                    string line;
                    Console.WriteLine("\n--- Employee Logs ---");

                    while ((line = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(line);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                Console.WriteLine("ViewLogs operation completed.");
            }
        }
    }
}
