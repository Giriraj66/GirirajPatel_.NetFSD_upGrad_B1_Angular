﻿namespace Assignment2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            while (true)
            {
                Console.WriteLine("==== Student Report Card System ====");
                Console.WriteLine("1. Generate Report Card");
                Console.WriteLine("2. View Report Card");
                Console.WriteLine("3. Exit");
                Console.Write("Enter choice: ");

                int choice;
                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Invalid input! Enter number only.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        GenerateReport();
                        break;
                    case 2:
                        ViewReport();
                        break;
                    case 3:
                        return;
                    default:
                        Console.WriteLine("Invalid choice!");
                        break;
                }
            }
        }
        static void GenerateReport()
        {
            try
            {
                Console.Write("Enter Student Name: ");
                string name = Console.ReadLine();

                Console.Write("Enter Roll Number: ");
                string roll = Console.ReadLine();

                int m1 = ReadMarks("Enter Marks for Subject 1: ");
                int m2 = ReadMarks("Enter Marks for Subject 2: ");
                int m3 = ReadMarks("Enter Marks for Subject 3: ");

                int total = m1 + m2 + m3;
                double avg = total / 3.0;

                string grade;
                if (avg >= 75) grade = "A";
                else if (avg >= 50) grade = "B";
                else if (avg >= 35) grade = "C";
                else grade = "Fail";

                string content =
                            $@"Student Name: {name}
                                Roll Number: {roll}
                                Marks: {m1}, {m2}, {m3}
                                Total: {total}
                                Average: {avg:F2}
                                Grade: {grade}";

                string fileName = roll + ".txt";

                File.WriteAllText(fileName, content);

                Console.WriteLine("Report card generated successfully!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        static void ViewReport()
        {
            try
            {
                Console.Write("Enter Roll Number: ");
                string roll = Console.ReadLine();

                string fileName = roll + ".txt";

                if (File.Exists(fileName))
                {
                    string data = File.ReadAllText(fileName);
                    Console.WriteLine("--- Student Report ---");
                    Console.WriteLine(data);
                }
                else
                {
                    Console.WriteLine("Report not found!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        static int ReadMarks(string message)
        {
            int marks;
            while (true)
            {
                Console.Write(message);
                if (int.TryParse(Console.ReadLine(), out marks) && marks >= 0 && marks <= 100)
                {
                    return marks;
                }
                else
                {
                    Console.WriteLine("Invalid marks! Enter value between 0–100.");
                }
            }
        }
    }
}
